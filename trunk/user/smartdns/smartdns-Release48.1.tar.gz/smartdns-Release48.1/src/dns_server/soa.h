/*************************************************************************
 *
 * Copyright (C) 2018-2025 Ruilin Peng (Nick) <pymumu@gmail.com>.
 *
 * smartdns is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * smartdns is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

#ifndef _DNS_SERVER_SOA_
#define _DNS_SERVER_SOA_

#include "dns_server.h"

#ifdef __cplusplus
extern "C" {
#endif /*__cplusplus */

int _dns_server_is_return_soa(struct dns_request *request);

void _dns_server_setup_soa(struct dns_request *request);

int _dns_server_is_return_soa_qtype(struct dns_request *request, dns_type_t qtype);

int _dns_server_reply_SOA(int rcode, struct dns_request *request);

int _dns_server_reply_SOA_ext(int rcode, struct dns_request *request);

int _dns_server_qtype_soa(struct dns_request *request);

#ifdef __cplusplus
}
#endif /*__cplusplus */
#endif
